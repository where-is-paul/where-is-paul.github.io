//sieve
void runEratosthenesSieve(int upperBound) {
	int upperBoundSquareRoot = (int)sqrt((double)upperBound);
	bool *isComposite = new bool[upperBound + 1];
    memset(isComposite, 0, sizeof(bool) * (upperBound + 1));
    for (int m = 2; m <= upperBoundSquareRoot; m++) {
        if (!isComposite[m]) {
            cout << m << " ";
				for (int k = m * m; k <= upperBound; k += m)
					isComposite[k] = true;
        }
    }
    /*for (int m = upperBoundSquareRoot; m <= upperBound; m++)
        if (!isComposite[m])
            cout << m << " ";*/
	  
    delete [] isComposite;
}

//slowest. divides up to n
bool is_prime(long long n) {
	for (int i = 2; i < N; i++)
		if (N % i == 0) return false;
	return true;
}

//significant speedup
bool is_prime(long long n) {
	for (int i = 2; i*i < N; i++)
		if (N % i == 0) return false;
	return true;
}

//fairly fast prime checker, only checks every 6 numbers (wheel factorization, spokes: 2, 3)
bool is_prime(long long n) {
	if (n == 1)
		return false;

	if (n == 2 || n == 3)
		return true;

	if (n % 2 == 0 || n % 3 == 0)
		return false;

	long long limit = ((long long) sqrt(n)) + 1;
	for ( long long i = 5; i <= limit; i += 6 ) {
		if ((n % i == 0) || (n % (i+2) == 0))
			return false;
	}

	return true;
}